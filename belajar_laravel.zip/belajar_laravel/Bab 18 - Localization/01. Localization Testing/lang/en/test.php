<?php

return [
    'judul' => 'Belajar Laravel Uncover',
];



// return [
//     'home' => [
//         'judul' => 'Belajar Laravel Uncover',
//     ]
// ];
