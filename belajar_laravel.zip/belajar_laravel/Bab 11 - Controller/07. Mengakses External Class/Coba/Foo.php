<?php

namespace App\Http\Controllers\Coba;

class Foo
{
    public function bar()
    {
        echo "Ini berasal dari Method Bar di dalam class Foo";
    }
}
