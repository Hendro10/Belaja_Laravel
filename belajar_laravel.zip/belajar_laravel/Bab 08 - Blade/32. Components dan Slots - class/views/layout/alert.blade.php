<div class="alert alert-{{$class}} alert-dismissible fade show">
  {{$slot}}
  <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>