<?php
  include 'model_mahasiswa.php';
  $isiTabelMahasiswa = getTableMahasiswa();
  include 'view_mahasiswa.php';
