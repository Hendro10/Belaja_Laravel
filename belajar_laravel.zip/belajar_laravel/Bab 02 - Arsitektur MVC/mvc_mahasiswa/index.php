<?php
  header('Location: controller_mahasiswa.php');
