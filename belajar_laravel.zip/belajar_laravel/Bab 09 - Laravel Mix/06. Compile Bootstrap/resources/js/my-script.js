// Tampilkan popover Bootstrap

new bootstrap.Popover(document.getElementById('myPopover'))