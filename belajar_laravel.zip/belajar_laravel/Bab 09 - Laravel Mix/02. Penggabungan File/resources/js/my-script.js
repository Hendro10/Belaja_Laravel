// Tampilkan alert ketika halaman di klik

window.addEventListener('click',function(){
    alert('Saya di klik');
});
