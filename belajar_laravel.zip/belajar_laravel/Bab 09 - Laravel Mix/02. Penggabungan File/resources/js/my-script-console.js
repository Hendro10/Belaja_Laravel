// Tampilkan pesan console ketika halaman di klik

window.addEventListener('click',function(){
    console.log('Saya juga di klik');
});
